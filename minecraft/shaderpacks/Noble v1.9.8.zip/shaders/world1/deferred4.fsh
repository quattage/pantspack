#version 430 compatibility

#define STAGE_FRAGMENT
#define WORLD_END

#include "/programs/deferred/diffuse_lighting_sky.glsl"
