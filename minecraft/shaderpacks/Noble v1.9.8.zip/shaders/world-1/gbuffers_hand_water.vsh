#version 430 compatibility

#define PROGRAM_HAND
#define STAGE_VERTEX
#define WORLD_NETHER

#include "/programs/gbuffers/forward.glsl"
