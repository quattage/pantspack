/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

/*
    [Credits]:
        sixthSurge - providing noise generator program for clouds shape and help with lighting (https://github.com/sixthsurge)
        
    [References]:
        Wrenninge et al. (2013). Oz: The Great and Volumetric. http://magnuswrenninge.com/wp-content/uploads/2010/03/Wrenninge-OzTheGreatAndVolumetric.pdf
        Schneider, A., & Vos, N. (2015). The Real-time Volumetric Cloudscapes of Horizon: Zero Dawn. https://www.guerrilla-games.com/media/News/Files/The-Real-time-Volumetric-Cloudscapes-of-Horizon-Zero-Dawn.pdf
        Hillaire, S. (2016). Physically Based Sky, Atmosphere and Cloud Rendering in Frostbite. https://media.contentapi.ea.com/content/dam/eacom/frostbite/files/s2016-pbs-frostbite-sky-clouds-new.pdf
        Högfeldt, R. (2016). Convincing Cloud Rendering An Implementation of Real-Time Dynamic Volumetric Clouds in Frostbite. https://odr.chalmers.se/server/api/core/bitstreams/c8634b02-1b52-40c7-a75c-d8c7a9594c2c/content
        Häggström, F. (2018). Real-time rendering of volumetric clouds. http://www.diva-portal.org/smash/get/diva2:1223894/FULLTEXT01.pdf
*/

// Clouds textures

uniform sampler3D colortex10;
uniform sampler3D colortex11;
uniform sampler3D depthtex2;

#define CURL_NOISE_TEXTURE   colortex10
#define SHAPE_NOISE_TEXTURE  depthtex2
#define DETAIL_NOISE_TEXTURE colortex11

// Clouds settings

struct CloudLayer {
    int8_t stepCount;

    float16_t scale;
    float16_t detailScale;
    float16_t frequency;

    float16_t density;

    float16_t altitude;
    float16_t thickness;
    float16_t coverage;
    float16_t swirl;
};

#define PARSE_CLOUD_LAYER_SETTINGS( \
    SCATTERING_STEPS, SCALE, DETAILSCALE, FREQUENCY, DENSITY, ALTITUDE, THICKNESS, COVERAGE, SWIRL \
) \
    CloudLayer(                      \
        int8_t(SCATTERING_STEPS              ), \
        float16_t(1e-5 + SCALE       * 9.9e-6), \
        float16_t(1e-5 + DETAILSCALE * 9.9e-6), \
        float16_t(FREQUENCY                  ), \
        float16_t(DENSITY            * 0.01  ), \
        float16_t(ALTITUDE                   ), \
        float16_t(THICKNESS                  ), \
        float16_t(COVERAGE           * 0.01  ), \
        float16_t(SWIRL              * 0.01  )  \
    )

const CloudLayer cloudLayer0 = PARSE_CLOUD_LAYER_SETTINGS(
    CLOUDS_LAYER0_SCATTERING_STEPS,
    CLOUDS_LAYER0_SCALE,
    CLOUDS_LAYER0_DETAILSCALE,
    CLOUDS_LAYER0_FREQUENCY,
    CLOUDS_LAYER0_DENSITY,
    CLOUDS_LAYER0_ALTITUDE,
    CLOUDS_LAYER0_THICKNESS,
    CLOUDS_LAYER0_COVERAGE,
    CLOUDS_LAYER0_SWIRL
);

const CloudLayer cloudLayer1 = PARSE_CLOUD_LAYER_SETTINGS(
    CLOUDS_LAYER1_SCATTERING_STEPS,
    CLOUDS_LAYER1_SCALE,
    CLOUDS_LAYER1_DETAILSCALE,
    CLOUDS_LAYER1_FREQUENCY,
    CLOUDS_LAYER1_DENSITY,
    CLOUDS_LAYER1_ALTITUDE,
    CLOUDS_LAYER1_THICKNESS,
    CLOUDS_LAYER1_COVERAGE,
    CLOUDS_LAYER1_SWIRL
);

const vec3 upVector = vec3(0.0, 1.0, 0.0);

// Wind constants

const vec3 windDirection = vec3(-0.7, 0.0, 0.7);
const vec3 wind          = windDirection * CLOUDS_WIND_SPEED;

float shapeAlter(float altitude, float weatherMap) {
    float stopHeight = saturate(weatherMap + 0.35);                           // Maximum cloud height

    return saturate(remap(altitude, 0.0, 0.07, 0.0, 1.0))                     // Round the clouds towards the bottom
         * saturate(remap(altitude, stopHeight * 0.2, stopHeight, 1.0, 0.0)); // Round the clouds towards the top
}

float densityAlter(float altitude, float weatherMap) {
    float densityAlter = altitude;

    densityAlter *= saturate(remap(altitude, 0.0, 0.7, 0.0, 1.0)); // Reduce density towards the bottom
    densityAlter *= saturate(remap(altitude, 0.7, 1.0, 1.0, 0.0)); // Softer transition towards the top
    densityAlter *= weatherMap * 2.0;                              // Make the weather map influence the density

    return densityAlter;
}

// Worley noise

const float WORLEY_CELLS_COUNT     = 16.0;
const float RCP_WORLEY_CELLS_COUNT = 1.0 / WORLEY_CELLS_COUNT;
const float RCP_WORLEY_LENGTH      = 1.0 / length(vec2(RCP_WORLEY_CELLS_COUNT));

vec2 getCellPoint(vec2 cell) {
    return (cell + hash22(cell)) * RCP_WORLEY_CELLS_COUNT;
}

float worley(vec2 coords) {
    vec2 cell = floor(coords * WORLEY_CELLS_COUNT);
    
    float dist = 1.0;

    const int neighbourhoodSize = 1;
    
    for (int x = -neighbourhoodSize; x <= neighbourhoodSize; x++) { 
        for (int y = -neighbourhoodSize; y <= neighbourhoodSize; y++) {
            dist = min(dist, distance(getCellPoint(cell + vec2(x, y)), coords));
        }
    }
    
    return 1.0 - dist * RCP_WORLEY_LENGTH;
}

// Clouds density

float calculateCloudsDensity(vec3 position, CloudLayer layer, bool isLowerLayer) {
    
    // The ray's height relative to the clouds thickness
    float heightPercentage = (position.y - (planetRadius + layer.altitude)) / layer.thickness;

    position += wind * frameTimeCounter;

    vec2 scaledCoords = position.xz * layer.scale;

    // Weather map

    float weatherMap = 0.0;

    if (isLowerLayer) {

        // Lower layer

        float globalCoverage = saturate(wetness + layer.coverage);

        float worleyNoise = worley(scaledCoords * 0.055);
              worleyNoise = remap(worleyNoise * worleyNoise, 0.1, 1.0, 0.0, 1.0);

        float bakedNoise = (
            remap(texture(noisetex, scaledCoords * mix(0.07, 0.01, wetness)).g * 1.5 - 0.25, saturate(0.4 - globalCoverage * 0.5), 1.0, 0.0, 1.0)
        );

        const float weatherMapCutoff = 0.4;

        weatherMap = remap(1.6 * (bakedNoise + worleyNoise * 0.3), saturate(weatherMapCutoff - globalCoverage * 0.5), 1.0, 0.0, 1.0) * 0.8 + 0.1;

    } else {

        // Upper layer

        weatherMap  = FBM(scaledCoords, 1, layer.frequency, 2.0, 0.5);
        weatherMap *= saturate(texture(noisetex, position.xz * 2e-4).b * 0.8 + 0.5);

        weatherMap = weatherMap * (1.0 - layer.coverage) + layer.coverage;

    }

    weatherMap = mix(weatherMap, 0.0, biome_arid);

    if (weatherMap <= 0.05) {
        return 0.0;
    }

    position *= layer.detailScale;

    // Curl

    const float curlNoiseScale = 0.2;

    vec3 curlTex   = texture(CURL_NOISE_TEXTURE, position * curlNoiseScale).rgb * 2.0 - 1.0;
         position += curlTex * layer.swirl;

    // Shape noise

    const float shapeNoiseScale = 0.5;

    vec4 shapeTex = texture(SHAPE_NOISE_TEXTURE, position * shapeNoiseScale);

    float shapeNoise = remap(shapeTex.r, (shapeTex.g * 0.625 + shapeTex.b * 0.25 + shapeTex.a * 0.125) - 1.0, 1.0, 0.0, 1.0); // Combine noise channels with FBM
          shapeNoise = remap(shapeNoise * shapeAlter(heightPercentage, weatherMap), 1.0 - 0.75 * weatherMap, 1.0, 0.0, 1.0);  // Height-dependent shape altering
    
    // Detail noise

    const float detailNoiseScale     = 3.0;
    const float detailNoiseIntensity = 0.6;

    vec3 detailTex = texture(DETAIL_NOISE_TEXTURE, position * detailNoiseScale).rgb;

    float detailNoise = detailTex.r * 0.625 + detailTex.g * 0.25 + detailTex.b * 0.125;
          detailNoise = detailNoiseIntensity * exp(-layer.coverage * 0.75) * mix(detailNoise, 1.0 - detailNoise, saturate(heightPercentage * 5.0));

    return saturate(remap(shapeNoise, detailNoise, 1.0, 0.0, 1.0)) * densityAlter(heightPercentage, weatherMap) * layer.density;
}

// Clouds raymarching

float calculateCloudsPhase(float cosTheta, vec3 mieAnisotropyFactors) {
    float forwardsLobe  = henyeyGreensteinPhase(cosTheta,  mieAnisotropyFactors.x);
    float backwardsLobe = henyeyGreensteinPhase(cosTheta, -mieAnisotropyFactors.y);
    float forwardsPeak  = henyeyGreensteinPhase(cosTheta,  mieAnisotropyFactors.z);

    return mix(mix(forwardsLobe, backwardsLobe, cloudsBackScatter), forwardsPeak, cloudsPeakWeight);
}

float calculateCloudsOpticalDepth(vec3 rayPosition, vec3 lightDirection, int stepCount, CloudLayer layer, bool isLowerLayer, bool animated) {
    float stepSize = 200.0, opticalDepth = 0.0;

    float jitter = animated ? randF() : bayer32(SCREEN_COORDS);

    for (int i = 0; i < stepCount; i++) {

        float density = calculateCloudsDensity(rayPosition + lightDirection * stepSize * jitter, layer, isLowerLayer);
        
        opticalDepth += density * stepSize;
        rayPosition  += lightDirection * stepSize;
    }

    return opticalDepth;
}

vec4 estimateCloudsScattering(CloudLayer layer, vec3 rayDirection, bool isLowerLayer, bool animated) {

    float cloudsLowerBound = planetRadius     + layer.altitude;
    float cloudsUpperBound = cloudsLowerBound + layer.thickness;

    vec2 distsToVolume = intersectSphericalShell(atmosphereRayPosition, rayDirection, cloudsLowerBound, cloudsUpperBound);
    
    if (distsToVolume.y < 0.0) {
        return vec4(0.0, 0.0, 1.0, cloudsFallbackDistance);
    }

    float jitter      = animated ? temporalBlueNoise(SCREEN_COORDS) : bayer64(SCREEN_COORDS);
    float stepSize    = (distsToVolume.y - distsToVolume.x) / layer.stepCount;
    vec3  rayPosition = atmosphereRayPosition + rayDirection * (distsToVolume.x + stepSize * jitter);
    vec3  increment   = rayDirection * stepSize;

    float distanceToClouds = distsToVolume.y;

    float VdotL = dot(rayDirection, shadowLightVectorWorld);
    float VdotU = dot(rayDirection, upVector);
    
    float bouncedLight = abs(-VdotU) * RCP_PI * 0.5 * isotropicPhase;

    vec2  scattering    = vec2(0.0);
    float transmittance = 1.0;

    // Adaptive steps
    
    int stepCount = int(mix(layer.stepCount * 0.25, float(layer.stepCount), saturate(length(rayPosition) / length(atmosphereRayPosition + rayDirection * distsToVolume.y))));
    
    for (int i = 0; i < stepCount && transmittance > cloudsTransmitThreshold; i++, rayPosition += increment) {

        float density = calculateCloudsDensity(rayPosition, layer, isLowerLayer);

        if (density > EPS) {

            float stepOpticalDepth  = cloudsExtinctionCoefficient * density * stepSize;
            float stepTransmittance = exp(-stepOpticalDepth);

            float directOpticalDepth = calculateCloudsOpticalDepth(rayPosition,  shadowLightVectorWorld, 4, layer, isLowerLayer, animated);
            float groundOpticalDepth = calculateCloudsOpticalDepth(rayPosition, -upVector,               1, layer, isLowerLayer, animated);
            float skyOpticalDepth    = calculateCloudsOpticalDepth(rayPosition,  upVector,               2, layer, isLowerLayer, animated);

            float powder    = 6.5 * (1.0 - 0.97 * exp(-8.0 * density));
            float powderSun = mix(powder, 1.0, VdotL * 0.5 + 0.5);
            float powderSky = mix(powder, 1.0, VdotU * 0.5 + 0.5);

            vec3  mieAnisotropyFactors  = vec3(cloudsForwardsLobe, cloudsBackardsLobe, cloudsForwardsPeak);
            float extinctionCoefficient = cloudsExtinctionCoefficient;
            float scatteringCoefficient = cloudsScatteringCoefficient;

            vec2 stepScattering = vec2(0.0);
            
            float cloudsPhase = calculateCloudsPhase(VdotL, mieAnisotropyFactors);

            mieAnisotropyFactors = pow(mieAnisotropyFactors, vec3(1.0 + directOpticalDepth));
            
            for (int j = 0; j < cloudsMultiScatterSteps; j++) {
                
                stepScattering.x += scatteringCoefficient * exp(-extinctionCoefficient * directOpticalDepth) * cloudsPhase    * powderSun;
                stepScattering.x += scatteringCoefficient * exp(-extinctionCoefficient * groundOpticalDepth) * bouncedLight   * powder;
                stepScattering.y += scatteringCoefficient * exp(-extinctionCoefficient * skyOpticalDepth   ) * isotropicPhase * powderSky;

                extinctionCoefficient *= cloudsExtinctionFalloff;
                scatteringCoefficient *= cloudsScatteringFalloff;
                mieAnisotropyFactors  *= cloudsAnisotropyFalloff;

                cloudsPhase = calculateCloudsPhase(VdotL, mieAnisotropyFactors);
            }
            
            float scatteringIntegral = (1.0 - stepTransmittance) * rcp(cloudsScatteringCoefficient);

            scattering    += stepScattering * scatteringIntegral * transmittance;
            transmittance *= stepTransmittance;

            distanceToClouds = min((i + jitter) * stepSize + distsToVolume.x, distanceToClouds);

        }
    }
    
    transmittance = linearStep(cloudsTransmitThreshold, 1.0, transmittance);

    return vec4(scattering, transmittance, distanceToClouds);
}

#if CLOUDS_SHADOWS == 1

    float calculateCloudsShadows(vec3 shadowPosition, CloudLayer layer) {
        float cloudsLowerBound = planetRadius     + layer.altitude;
        float cloudsUpperBound = cloudsLowerBound + layer.thickness;

        vec2 distsToVolume = intersectSphericalShell(shadowPosition, shadowLightVectorWorld, cloudsLowerBound, cloudsUpperBound);

        float stepSize    = (distsToVolume.y - distsToVolume.x) * RCP_CLOUDS_SHADOWS_STEPS;
        vec3  increment   = shadowLightVectorWorld * stepSize;
        vec3  rayPosition = shadowPosition + shadowLightVectorWorld * (distsToVolume.x + stepSize * 0.5);

        float opticalDepth = 0.0;

        for (int i = 0; i < CLOUDS_SHADOWS_STEPS; i++, rayPosition += increment) {
            opticalDepth += calculateCloudsDensity(rayPosition, layer, true);
        }

        return exp(-cloudsExtinctionCoefficient * opticalDepth * stepSize);
    }

#endif
