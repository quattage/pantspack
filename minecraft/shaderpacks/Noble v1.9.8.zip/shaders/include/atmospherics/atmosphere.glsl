/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

/*
    [Credits]:
        Jessie - help with atmospheric scattering and providing ozone cross section approximation (https://github.com/Jessie-LC)
        Zombye - sky illuminance sampling approximation (https://github.com/zombye)
        
    [References]:
        Nishita, T. (1993). Display of the earth taking into account atmospheric scattering. http://nishitalab.org/user/nis/cdrom/sig93_nis.pdf
        Elek, O. (2009). Rendering Parametrizable Planetary Atmospheres with Multiple Scattering in Real-Time. https://old.cescg.org/CESCG-2009/papers/PragueCUNI-Elek-Oskar09.pdf
        Jimenez et al. (2016). Practical Real-Time Strategies for Accurate Indirect Occlusion. https://www.activision.com/cdn/research/Practical_Real_Time_Strategies_for_Accurate_Indirect_Occlusion_NEW%20VERSION_COLOR.pdf 
        Mayaux, B. (n.d.). Spherical Harmonics. https://patapom.com/blog/SHPortal/
        Wikipedia. (2023). Table of spherical harmonics. https://en.wikipedia.org/wiki/Table_of_spherical_harmonics
    
    [Notes]:
        The scattering/transmittance evaluations are standard Riemann sum integrations.
        position + increment * 0.5 is midpoint sampling, it improves accuracy by "placing" the samples better.
        It reduces error of the Riemann sum from ~O(h) for endpoint sampling to ~O(h²) (more accurate).
*/

vec3 getAtmosphereDensities(float centerDist) {
    float altitudeKm = (centerDist - planetRadius) * m_to_km;

    vec2 rayleighMie = exp(altitudeKm * -invScaleHeights * km_to_m);

    float ozone = 0.0;

    #if defined WORLD_OVERWORLD

        // Ozone approximation from Jessie
        float o1 = 25.0 *     exp(( 0.0 - altitudeKm) * rcp(  8.0));
        float o2 = 30.0 * pow(exp((18.0 - altitudeKm) * rcp( 80.0)), altitudeKm - 18.0);
        float o3 = 75.0 * pow(exp((25.3 - altitudeKm) * rcp( 35.0)), altitudeKm - 25.3);
        float o4 = 50.0 * pow(exp((30.0 - altitudeKm) * rcp(150.0)), altitudeKm - 30.0);
        
        ozone = (o1 + o2 + o3 + o4) * rcp(134.628);

    #endif

    return vec3(rayleighMie, ozone);
}

vec3 evaluateAtmosphereTransmittance(vec3 origin, vec3 lightDirection, mat3x3 attenuationCoefficients) {

    float stepSize    = intersectSphere(origin, lightDirection, atmosphereUpperRadius).y * RCP_ATMOSPHERE_TRANSMITTANCE_STEPS;
    vec3  increment   = lightDirection * stepSize;
    vec3  rayPosition = origin + increment * 0.5;

    vec3 accumAirmass = vec3(0.0);

    // Transmittance evaluation
    
    for (int i = 0; i < ATMOSPHERE_TRANSMITTANCE_STEPS; i++, rayPosition += increment) {
        accumAirmass += getAtmosphereDensities(length(rayPosition)) * stepSize;
    }

    return exp(-attenuationCoefficients * accumAirmass);
}

#if defined STAGE_FRAGMENT

    vec3 evaluateAtmosphericScattering(vec3 rayDirection, vec3 skyIlluminance) {

        // Ray marching setup, the ray starts at the volume's bounds

        vec2 distsToVolume = intersectSphericalShell(atmosphereRayPosition, rayDirection, atmosphereLowerRadius, atmosphereUpperRadius);

        if (distsToVolume.y < 0.0) { return vec3(0.0); }

        float stepSize   = (distsToVolume.y - distsToVolume.x) * RCP_ATMOSPHERE_SCATTERING_STEPS;
        vec3 increment   = rayDirection * stepSize;
        vec3 rayPosition = atmosphereRayPosition + increment * 0.5;

        // Phases

        #if defined WORLD_OVERWORLD

            vec2 VdotL = vec2(dot(rayDirection, sunVector), dot(rayDirection, moonVector));
            vec4 phase = vec4(
                vec2(rayleighPhase(VdotL.x), kleinNishinaPhase(VdotL.x, mieAnisotropyFactor)), 
                vec2(rayleighPhase(VdotL.y), kleinNishinaPhase(VdotL.y, mieAnisotropyFactor))
            );

            const mat2x3 scatteringCoefficients  = atmosphereScatteringCoefficients;
            const mat3x3 attenuationCoefficients = atmosphereAttenuationCoefficients;

        #elif defined WORLD_END

            float VdotL = dot(rayDirection, starVector);
            vec2  phase = vec2(rayleighPhase(VdotL), kleinNishinaPhase(VdotL, mieAnisotropyFactor));

            const mat2x3 scatteringCoefficients  = atmosphereScatteringCoefficientsEnd;
            const mat3x3 attenuationCoefficients = atmosphereAttenuationCoefficientsEnd;

        #endif

        // Tracing

        mat2x3 scattering = mat2x3(vec3(0.0), vec3(0.0));

        vec3 multipleScattering = vec3(0.0);
        
        vec3 transmittance = vec3(1.0);
        
        for (int i = 0; i < ATMOSPHERE_SCATTERING_STEPS; i++, rayPosition += increment) {

            // Density function

            vec3 airmass = getAtmosphereDensities(length(rayPosition)) * stepSize;

            // Scattering evaluation

            vec3 stepOpticalDepth  = attenuationCoefficients * airmass;
            vec3 stepTransmittance = exp(-stepOpticalDepth);
            vec3 visibleScattering = transmittance * saturate((stepTransmittance - 1.0) / -stepOpticalDepth);

            #if defined WORLD_OVERWORLD

                vec3 sunStepScattering  = scatteringCoefficients * (airmass.xy * phase.xy) * visibleScattering;
                vec3 moonStepScattering = scatteringCoefficients * (airmass.xy * phase.zw) * visibleScattering;

                scattering[0] += sunStepScattering  * evaluateAtmosphereTransmittance(rayPosition, sunVector , attenuationCoefficients);
                scattering[1] += moonStepScattering * evaluateAtmosphereTransmittance(rayPosition, moonVector, attenuationCoefficients);

            #elif defined WORLD_END

                vec3 starStepScattering = scatteringCoefficients * (airmass.xy * phase) * visibleScattering;
                
                scattering[0] += starStepScattering * evaluateAtmosphereTransmittance(rayPosition, starVector, attenuationCoefficients);

            #endif

            // Multiple scattering approximation

            vec3 stepScattering       = scatteringCoefficients * airmass.xy;
            vec3 stepScatteringAlbedo = stepScattering / stepOpticalDepth;

            vec3 multScatteringFactor = stepScatteringAlbedo * 0.84;
            vec3 multScatteringEnergy = multScatteringFactor / (1.0 - multScatteringFactor);
                 multipleScattering  += multScatteringEnergy * visibleScattering * stepScattering;

            transmittance *= stepTransmittance;
        }
        
        multipleScattering *= skyIlluminance * isotropicPhase;

        #if defined WORLD_OVERWORLD

            scattering[0] *= sunIlluminance;
            scattering[1] *= moonIlluminance;

        #elif defined WORLD_END

            scattering[0] *= starIlluminance;

        #endif
    
        return scattering[0] + scattering[1] + multipleScattering;
    }

#endif

vec3 evaluateDirectIlluminance() {
    vec3 directIlluminance = vec3(0.0);

    #if defined WORLD_OVERWORLD

        vec3 sunDirection  = sunVector;
        vec3 moonDirection = moonVector;

        #if !defined IS_IRIS
            // Sun position code from builderb0y
            const vec2 sunRotationData = vec2(cos(sunPathRotation * degrees_to_radians), -sin(sunPathRotation * degrees_to_radians));

            float angle = fract(worldTime / 24000.0 - 0.25);
                  angle = (angle + (cos(angle * PI) * -0.5 + 0.5 - angle) / 3.0) * TAU;

            sunDirection = normalize(vec3(-sin(angle), cos(angle) * sunRotationData));

            moonDirection = -sunDirection;

        #endif

        vec3 sunTransmittance  = evaluateAtmosphereTransmittance(atmosphereRayPosition, sunDirection , atmosphereAttenuationCoefficients);
        vec3 moonTransmittance = evaluateAtmosphereTransmittance(atmosphereRayPosition, moonDirection, atmosphereAttenuationCoefficients);

        directIlluminance += sunTransmittance  * sunIlluminance;
        directIlluminance += moonTransmittance * moonIlluminance;

    #elif defined WORLD_END

        directIlluminance += evaluateAtmosphereTransmittance(atmosphereRayPosition, starVector, atmosphereAttenuationCoefficientsEnd) * starIlluminance;

    #endif

    return max0(directIlluminance);
}

vec3 sampleAtmosphereTexture(vec2 coords, bool monochrome) {
    vec3 radiance = texture(ATMOSPHERE_BUFFER, coords).rgb;

    return monochrome ? vec3(luminance(radiance)) : radiance;
}

vec3 evaluateUniformSkyIlluminanceApproximation() {
    vec3 skyIlluminance = vec3(0.0);

    const ivec2 samples        = ivec2(16, 8);
    const float invSampleCount = 1.0 / float(samples.x * samples.y);

    for (int x = 0; x < samples.x; x++) {
        for (int y = 0; y < samples.y; y++) {

            vec2 uv = (vec2(x, y) + 0.5) / vec2(samples.x, samples.y * 2);

            vec3 direction = unprojectSphere(uv);
            vec3 radiance  = sampleAtmosphereTexture(uv, false);

            float theta    = uv.y * PI;
            float cosTheta = cos(theta);
            float sinTheta = sin(theta);

            skyIlluminance += radiance * cosTheta * sinTheta;
        }
    }

    const float normalization = PI * PI * invSampleCount;

    skyIlluminance *= normalization;

    return max0(skyIlluminance);
}

vec3 evaluateSkylight(vec3 normal, mat3[2] skylight) {
    vec3 octahedronPoint = normal / dot(abs(normal), vec3(1.0));
    vec3 positive = saturate(octahedronPoint), negative = saturate(-octahedronPoint);
    
    return skylight[0][0] * positive.x + skylight[0][1] * positive.y + skylight[0][2] * positive.z
         + skylight[1][0] * negative.x + skylight[1][1] * negative.y + skylight[1][2] * negative.z;
}

// Spherical Harmonics Coefficients for 2 orders
float[9] calculateSphericalHarmonicsCoefficients(vec3 wi) {
    return float[9](
        0.28209479,

        0.48860251 * wi.y,
        0.48860251 * wi.z,
        0.48860251 * wi.x,

        1.09254843 * wi.x * wi.y,
        1.09254843 * wi.y * wi.z,
        0.31539156 * (3.0 * wi.z * wi.z - 1.0),
        1.09254843 * wi.x * wi.z,
        0.54627421 * (wi.x * wi.x - wi.y * wi.y)
    );
}

void evaluateUniformSkyIlluminance(out vec3[9] skyIlluminance) {

    for (int i = 0; i < 9; i++) {
        skyIlluminance[i] = vec3(0.0);
    }

    bool monochrome = false;

    #if defined WORLD_OVERWORLD
        monochrome = true;
    #endif

    const ivec2 samples        = ivec2(8, 8);
    const float invSampleCount = 1.0 / float(samples.x * samples.y);

    for (int x = 0; x < samples.x; x++) {
        for (int y = 0; y < samples.y; y++) {

            vec2 uv = (vec2(x, y) + 0.5) / vec2(samples.x, samples.y * 2);

            vec3 direction = unprojectSphere(uv);
            vec3 radiance  = sampleAtmosphereTexture(uv, monochrome);

            float theta    = uv.y * PI;
            float cosTheta = cos(theta);
            float sinTheta = sin(theta);

            float[9] sh = calculateSphericalHarmonicsCoefficients(direction);

            for (int i = 0; i < 9; i++) {
                skyIlluminance[i] += radiance * sh[i] * sinTheta;
                // The cosTheta jacobian term isn't needed here because Lambertian convolution accounts for it later
            }
        }
    }

    const float normalization = PI * PI * invSampleCount;

    for (int i = 0; i < 9; i++) {
        skyIlluminance[i] *= normalization;
    }
}

vec3 evaluateDirectionalSkyIlluminance(vec3[9] illuminance, vec3 bentNormal, float visibility) {
    float[9] sh = calculateSphericalHarmonicsCoefficients(bentNormal);

    // Lambertian convolution
    const float A0 = PI;
    const float A1 = TAU / 3.0;
    const float A2 = PI  / 4.0;

    vec3 result = illuminance[0] * A0 * sh[0]
                + (illuminance[1] * sh[1] + illuminance[2] * sh[2] + illuminance[3] * sh[3]) * A1
                + (illuminance[4] * sh[4] + illuminance[5] * sh[5] + illuminance[6] * sh[6] + illuminance[7] * sh[7] + illuminance[8] * sh[8]) * A2;

    return max0(result * visibility);
}
