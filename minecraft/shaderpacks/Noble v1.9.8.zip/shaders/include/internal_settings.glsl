/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

#if AO == 1
    const float ambientOcclusionLevel = 0.0;
#else
    const float ambientOcclusionLevel = 1.0;
#endif

/*

// ============================================================================
// SHADOW MAP TEXTURES / SHADOW BUFFER
// ============================================================================

const int shadowcolor0Format = RGBA8;               // Shadow color (albedo)

#if WATER_CAUSTICS == 1

    const int shadowcolor1Format = R16F;            // Water caustics

#endif

const int colortex3Format = RGBA16F;                // Shadow map

// ============================================================================
// MAIN COLOR / GBUFFERS
// ============================================================================

const int  colortex0Format = RGBA16F;               // Main color

const int  colortex1Format = RGBA32UI;              // GBuffer data:
                                                    // [R] parallax self shadowing | lightmap XY coordinates
                                                    // [G] material AO | emission | F0 | subsurface
                                                    // [B] texture albedo RGB | roughness
                                                    // [A] encoded XY material normals

const int colortex15Format = RGBA8;                 // Alpha blended GBuffer data (albedo)

const int colortex13Format = R16F;                  // Depth tiles

// ============================================================================
// REFLECTIONS
// ============================================================================

#if REFLECTIONS > 0

    const int  colortex2Format = RGBA16F;           // Reflections
    const bool colortex2Clear  = false;

#endif

// ============================================================================
// ILLUMINANCE / CLOUDS SHADOWS / BLOOM
// ============================================================================

const int colortex5Format = RGBA16F;                // Illuminance | Clouds shadows | Bloom

// ============================================================================
// ATMOSPHERE
// ============================================================================

const int  colortex6Format = R11F_G11F_B10F;        // Atmosphere
const bool colortex6Clear  = false;

// ============================================================================
// CLOUDS
// ============================================================================

#if defined CLOUDS_ENABLED

    const int  colortex7Format = RGBA16F;           // Clouds
    const bool colortex7Clear  = false;

#endif

#if CLOUDMAP == 1

    const int colortex14Format = R11F_G11F_B10F;    // Cloud map (low resolution)

#endif

// ============================================================================
// TEMPORAL DATA / HISTORY
// ============================================================================

const int colortex4Format = RG16F;                  // Previous frame Depth | Temporal accumulation weight
const bool colortex4Clear = false;

const int  colortex8Format = RGBA16F;               // [RGB] Previous color | [A] Average luminance
const bool colortex8Clear  = false;

// ============================================================================
// AMBIENT OCCLUSION
// ============================================================================

#if AO > 0

    const int  colortex12Format = RGB16F;           // Ambient occlusion
    const bool colortex12Clear  = false;

#endif

*/
