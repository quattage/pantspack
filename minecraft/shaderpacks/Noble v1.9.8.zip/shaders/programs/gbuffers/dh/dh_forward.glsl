/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

#include "/settings.glsl"
#include "/include/taau_scale.glsl"

#include "/include/common.glsl"

#include "/include/atmospherics/atmosphere_header.glsl"

#if defined STAGE_VERTEX

    flat out uint blockId;
    
    out vec2 lightmapCoords;

    out vec3 vertexNormal;
    out vec4 vertexColor;

    out vec3 scenePosition;

    flat out vec3 directIlluminance;
    flat out vec3 skyIlluminance;

    #include "/include/atmospherics/illuminance_fetch.glsl"

    void main() {
        lightmapCoords = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
        vertexColor    = gl_Color;
        blockId        = uint(dhMaterialId);

        vertexNormal = mat3(gbufferModelViewInverse) * (mat3(gl_ModelViewMatrix) * gl_Normal);
        
        vec3 cameraOffset   = fract(cameraPosition);
        vec3 vertexPosition = floor(gl_Vertex.xyz + cameraOffset + 0.5) - cameraOffset;

        vec3 viewPosition = transform(gl_ModelViewMatrix, vertexPosition);

        scenePosition = transform(gbufferModelViewInverse, viewPosition);

        #if defined OVERWORLD_OR_END

            directIlluminance = DIRECT_ILLUMINANCE();
            skyIlluminance    = UNIFORM_SKY_ILLUMINANCE();
            
        #endif
        
        gl_Position    = modProjection * vec4(viewPosition, 1.0);
        gl_Position.xy = gl_Position.xy * RENDER_SCALE + (RENDER_SCALE - 1.0) * gl_Position.w;

        TAA_JITTER(gl_Position);
    }

#elif defined STAGE_FRAGMENT

    /* RENDERTARGETS: 1,0 */

    layout (location = 0) out uvec4 dataOut;
    layout (location = 1) out vec4 translucentsOut;

    flat in uint blockId;

    in vec2 lightmapCoords;

    in vec3 vertexNormal;
    in vec4 vertexColor;

    in vec3 scenePosition;

    flat in vec3 directIlluminance;
    flat in vec3 skyIlluminance;

    #include "/include/utility/rng.glsl"
    
    #include "/include/material/brdf.glsl"

    #if SHADOWS > 0
        #include "/include/fragment/shadows.glsl"
    #endif

    #include "/include/utility/sampling.glsl"

    #include "/include/fragment/water.glsl"

    #include "/include/post/exposure.glsl"

    void main() {
        
        translucentsOut = vec4(0.0);

        #if DOWNSCALED_RENDERING == 1
            vec2 fragCoords = gl_FragCoord.xy * texelSize;
            if (!insideScreenBounds(fragCoords, RENDER_SCALE)) { return; }
        #endif

        float depth       = texelFetch(depthtex0, ivec2(gl_FragCoord.xy), 0).r;
        float linearDepth = linearizeDepth(depth);
    
        if (depth < 1.0) { return; }

        Material material;

        material.albedo = vertexColor.rgb;

        material.lightmap = lightmapCoords;
        material.normal   = vertexNormal;

        material.ao         = 1.0;
        material.subsurface = 0.0;

        // WOTAH
        if (blockId == DH_BLOCK_WATER) {

            material.F0       = waterF0;
            material.alpha    = 0.0;
            material.emission = 0.0;
            material.albedo   = vec3(1.0);

            material.normal = getWaterNormal(scenePosition + cameraPosition, vec3(0.0, 1.0, 0.0), WATER_OCTAVES);

        } else {

            // Forward diffuse lighting

            material.F0 = 0.0;

            material.alpha = saturate(hardcodedRoughness != 0.0 ? hardcodedRoughness : 0.0);

            if (blockId == DH_BLOCK_ILLUMINATED) {
                material.emission = 1.0;
            }

            #if WHITE_WORLD == 1
                material.albedo = vec3(1.0);
            #endif

            material.albedo = SRGB_TO_WORKING_SPACE(material.albedo);

            material.N = vec3(f0ToIOR(material.F0));
            material.K = vec3(0.0);

            vec4 shadowmap = vec4(1.0, 1.0, 1.0, 0.0);

            #if defined WORLD_OVERWORLD && SHADOWS > 0

                shadowmap = calculateShadowMapping(scenePosition, vertexNormal, gl_FragDepth);
            
            #endif

            translucentsOut.rgb = computeDiffuse(
                scenePosition,
                shadowLightVectorWorld,
                material,
                false,
                shadowmap,
                directIlluminance,
                skyIlluminance,
                1.0,
                1.0
            );

            translucentsOut.rgb *= CURRENT_EXPOSURE();

            translucentsOut.a = vertexColor.a;

        }

        // Material encoding
        
        vec2 encodedNormal = encodeUnitVector(normalize(material.normal));

        dataOut = storeMaterial(
            material.F0,
            material.alpha,
            material.ao,
            material.emission,
            material.subsurface,
            material.albedo,
            encodedNormal,
            material.lightmap,
            1.0,
            blockId
        );
    }

#endif
