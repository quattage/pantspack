/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

#include "/settings.glsl"
#include "/include/taau_scale.glsl"

#include "/include/common.glsl"

#if defined STAGE_VERTEX

    flat out uint blockId;
    
    out vec2 lightmapCoords;

    out vec3 vertexNormal;
    out vec4 vertexColor;

    out vec3 scenePosition;

    void main() {
        lightmapCoords = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
        vertexColor    = gl_Color;
        blockId        = uint(dhMaterialId);

        vertexNormal = mat3(gbufferModelViewInverse) * (mat3(gl_ModelViewMatrix) * gl_Normal);

        vec3 cameraOffset   = fract(cameraPosition);
        vec3 vertexPosition = floor(gl_Vertex.xyz + cameraOffset + 0.5) - cameraOffset;

        vec3 viewPosition = transform(gl_ModelViewMatrix, vertexPosition);

        scenePosition = transform(gbufferModelViewInverse, viewPosition);

        gl_Position    = modProjection * vec4(viewPosition, 1.0);
        gl_Position.xy = gl_Position.xy * RENDER_SCALE + (RENDER_SCALE - 1.0) * gl_Position.w;

        TAA_JITTER(gl_Position);
    }

#elif defined STAGE_FRAGMENT

    /* RENDERTARGETS: 1 */

    layout (location = 0) out uvec4 dataOut;

    flat in uint blockId;

    in vec2 lightmapCoords;

    in vec3 vertexNormal;
    in vec4 vertexColor;

    in vec3 scenePosition;

    #if RAIN_PUDDLES == 1
        #include "/include/material/rain_puddles.glsl"
    #endif

    void main() {
        
        #if DOWNSCALED_RENDERING == 1
            vec2 fragCoords = gl_FragCoord.xy * texelSize;
            if (!insideScreenBounds(fragCoords, RENDER_SCALE)) { return; }
        #endif

        float fragDistance = length(scenePosition);
        if (fragDistance < 0.5 * far) { return; }

        vec3 albedo = vertexColor.rgb;

        #if WHITE_WORLD == 1
            albedo = vec3(1.0);
        #endif

        vec3 normal = vertexNormal;

        float F0 = 0.0;

        float roughness = saturate(hardcodedRoughness != 0.0 ? hardcodedRoughness : 1.0);

        // Rain puddles

        #if RAIN_PUDDLES == 1

            if (wetness > 0.0 && biome_may_rain > 0.0 && isEyeInWater == 0) {
            
                rainPuddles(scenePosition, vertexNormal, lightmapCoords, 0.0, albedo, normal, F0, roughness);

            }

        #endif

        // Hardcoded LabPBR values

        float emission = 0.0;

        #if HARDCODED_EMISSION == 1

            if (blockId == DH_BLOCK_ILLUMINATED) {
                emission = HARDCODED_EMISSION_VAL;
            }

        #endif

        float subsurface = 0.0;

        #if HARDCODED_SSS == 1

            if (blockId == DH_BLOCK_LEAVES || blockId == DH_BLOCK_SNOW || blockId == DH_BLOCK_SAND) {
                subsurface = HARDCODED_SSS_VAL;
            }

        #endif

        // Material encoding

        vec2 encodedNormal = encodeUnitVector(normalize(normal));

        dataOut = storeMaterial(
            F0,
            roughness,
            1.0,
            emission,
            subsurface,
            albedo,
            encodedNormal,
            lightmapCoords,
            1.0,
            blockId
        );
    }

#endif
