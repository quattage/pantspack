/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

#include "/settings.glsl"
#include "/include/taau_scale.glsl"
#include "/include/common.glsl"

const ivec3 workGroups = ivec3(1, 1, 1);

#if defined OVERWORLD_OR_END

    #include "/include/atmospherics/atmosphere_header.glsl"

    #if defined IS_IRIS

        layout (local_size_x = 1, local_size_y = 1, local_size_z = 1) in;

        #include "/include/atmospherics/illuminance_fetch.glsl"

        void main() {
            DIRECT_ILLUMINANCE() = evaluateDirectIlluminance();

            UNIFORM_SKY_ILLUMINANCE() = evaluateUniformSkyIlluminanceApproximation();

            evaluateUniformSkyIlluminance(SKY_ILLUMINANCE_COEFFICIENTS());
        }      

    #else

        layout (rgba16f) uniform image2D colorimg5;

        layout (local_size_x = 10, local_size_y = 1, local_size_z = 1) in;

        shared vec3 skyIlluminance[9];

        void main() {
            uint x = gl_LocalInvocationID.x;

            if (x == 1) {
                evaluateUniformSkyIlluminance(skyIlluminance);
            }

            memoryBarrierShared();
            barrier();

            vec3 illuminance = vec3(0.0);

            if (x == 0) {
                // Direct illuminance
                illuminance = encodeLog(evaluateDirectIlluminance());

            } else if (x == 1) {
                // Uniform sky illuminance
                illuminance = evaluateUniformSkyIlluminanceApproximation();
                
            } else if (x > 1 && x < 11) {
                // Sky illuminance (9 coefficients)
                illuminance = skyIlluminance[x - 2];
            }

            imageStore(colorimg5, ivec2(0, x), vec4(illuminance, 0.0));
        }

    #endif

#else

    layout (local_size_x = 1, local_size_y = 1, local_size_z = 1) in;

    void main() {
        return;
    }

#endif
